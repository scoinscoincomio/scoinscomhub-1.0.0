#pragma once

#include <system_error>
#include <eosio/vm/error_codes_def.hpp>
