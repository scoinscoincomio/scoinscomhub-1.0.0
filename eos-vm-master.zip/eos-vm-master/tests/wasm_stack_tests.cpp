#include <catch2/catch.hpp>
#include <eosio/vm/allocator.hpp>
#include <eosio/vm/wasm
